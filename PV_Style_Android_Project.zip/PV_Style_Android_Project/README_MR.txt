P&V Style Android Project (v1.0)

या ZIP मध्ये Android अ‍ॅपचा प्रोजेक्ट आणि GitHub Actions द्वारे APK build करण्याची workflow आहे.
हा ZIP स्वतः APK नाही.

फोनवरून APK तयार करण्याची पद्धत:
1) ZIP extract न करता संपूर्ण ZIP GitHub वर नवीन repository मध्ये upload करा (किंवा PC वर extract करून files upload करा).
2) Repository -> Actions मध्ये "Build P&V Style APK" workflow चालू/Run workflow करा.
3) Build पूर्ण झाल्यावर workflow मधील run उघडा.
4) Artifacts विभागातून PV-Style-debug-APK डाउनलोड करा.
5) ZIP artifact extract करा; app-debug.apk फोनवर डाउनलोड करून उघडा आणि install करा.
   फोनने विचारल्यास या स्रोतावरून install करण्याची परवानगी द्या.

टीप:
- APK ही debug/sideload build आहे, Play Store साठी signed release नाही.
- फोटो edit आणि PDF viewing ही प्राथमिक सुविधा आहे.
- PDF चे मजकूर संपादन या आवृत्तीत नाही.
- Build failure आल्यास Actions मधील error तपासून project update करावा लागू शकतो.
